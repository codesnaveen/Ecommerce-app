# ShopKart — Complete Hosting Guide

## Architecture Overview

```
User Browser
    │
    ├── React (Vercel) ──────────────► Django API (Railway)
    │         free tier                    └── PostgreSQL (Railway)
    │                                      └── Redis (Upstash — free)
    │                                      └── Media Files (Cloudflare R2)
    └── Stripe Payments (client-side SDK + server webhook)
```

---

## Part 1 — Run Locally (5 minutes)

### Backend setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Copy and fill env file
cp .env.example .env
# Edit .env: set SECRET_KEY, Stripe keys (get from stripe.com/dashboard)

# Run migrations
python manage.py migrate

# Seed 20 demo products + admin user
python manage.py seed_data

# Start server
python manage.py runserver
# → http://localhost:8000
# Admin panel: http://localhost:8000/admin  (admin@shopkart.com / Admin@1234)
```

### Frontend setup

```bash
cd frontend

npm install

cp .env.example .env
# Leave VITE_API_URL empty for local dev (Vite proxy handles it)

npm run dev
# → http://localhost:5173
```

### Redis + Celery (optional for email in dev)

```bash
# macOS
brew install redis && redis-server

# Ubuntu
sudo apt install redis-server && sudo service redis start

# Start Celery worker (separate terminal)
cd backend
celery -A config worker --loglevel=info
```

---

## Part 2 — Deploy Backend to Railway

Railway gives you **free PostgreSQL + free $5 credit/month** — plenty for a portfolio project.

### Step 1 — Create Railway account

Go to [railway.app](https://railway.app) and sign up with GitHub.

### Step 2 — Create a new project

```
Railway Dashboard → New Project → Deploy from GitHub repo
Select your repo → Choose the /backend folder
```

### Step 3 — Add PostgreSQL

```
Railway project → + New → Database → PostgreSQL
```

Railway auto-sets `DATABASE_URL` in your service. No manual config needed.

### Step 4 — Add Redis (Upstash — free tier)

1. Go to [upstash.com](https://upstash.com) → Create free Redis database
2. Copy the `REDIS_URL` (starts with `rediss://`)
3. Add it to Railway environment variables

### Step 5 — Set environment variables in Railway

In your Railway service → Variables tab, add these:

```
SECRET_KEY          = (generate: python -c "import secrets; print(secrets.token_urlsafe(50))")
DEBUG               = False
ALLOWED_HOSTS       = your-app.up.railway.app
CORS_ALLOWED_ORIGINS= https://your-frontend.vercel.app
DATABASE_URL        = (auto-set by Railway PostgreSQL plugin)
REDIS_URL           = rediss://your-upstash-url
STRIPE_SECRET_KEY   = sk_live_... (or sk_test_... for testing)
STRIPE_PUBLISHABLE_KEY = pk_live_...
STRIPE_WEBHOOK_SECRET  = whsec_... (set after step in Part 4)
EMAIL_BACKEND       = django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST_USER     = your-gmail@gmail.com
EMAIL_HOST_PASSWORD = your-gmail-app-password
USE_S3              = False
```

### Step 6 — Add build commands

In Railway service → Settings → Deploy:

```
Build Command:  pip install -r requirements.txt && python manage.py collectstatic --noinput && python manage.py migrate
Start Command:  gunicorn config.wsgi:application --bind 0.0.0.0:$PORT
```

### Step 7 — Seed production data

Open Railway service shell:

```bash
python manage.py seed_data
python manage.py createsuperuser  # optional extra admin
```

Your API is now live at: `https://your-app.up.railway.app`

---

## Part 3 — Deploy Frontend to Vercel

### Step 1 — Push code to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourname/shopkart.git
git push -u origin main
```

### Step 2 — Import to Vercel

1. Go to [vercel.com](https://vercel.com) → New Project
2. Import your GitHub repository
3. Set **Root Directory** to `frontend`
4. Framework Preset: **Vite**

### Step 3 — Set environment variable in Vercel

```
VITE_API_URL = https://your-app.up.railway.app/api
```

### Step 4 — Deploy

Click Deploy. Vercel builds and deploys in ~60 seconds.

Your frontend is live at: `https://shopkart.vercel.app`

---

## Part 4 — Configure Stripe Webhooks

Stripe webhooks tell your backend when a payment succeeds — this is how orders get confirmed.

### Step 1 — Install Stripe CLI (for local testing)

```bash
# macOS
brew install stripe/stripe-cli/stripe

# Login
stripe login

# Forward webhooks to local Django
stripe listen --forward-to localhost:8000/api/payments/webhook/
# Copy the webhook signing secret (whsec_...) → paste in your .env
```

### Step 2 — Production webhook (after deploying)

1. Go to [dashboard.stripe.com/webhooks](https://dashboard.stripe.com/webhooks)
2. Click **Add endpoint**
3. URL: `https://your-app.up.railway.app/api/payments/webhook/`
4. Select events:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
5. Copy the **Signing secret** → add as `STRIPE_WEBHOOK_SECRET` in Railway

### Test card numbers

| Card | Result |
|------|--------|
| 4242 4242 4242 4242 | Payment succeeds |
| 4000 0000 0000 9995 | Payment declined |
| 4000 0025 0000 3155 | 3D Secure required |

Use any future expiry date and any 3-digit CVC.

---

## Part 5 — Add Media File Storage (Cloudflare R2)

By default, uploaded product images are stored on the server (not persistent on Railway). Use R2 for production.

### Step 1 — Create Cloudflare R2 bucket

1. [dash.cloudflare.com](https://dash.cloudflare.com) → R2 → Create bucket → name: `shopkart-media`
2. R2 → Manage API tokens → Create token with **Object Read & Write** permission
3. Note your **Account ID**, **Access Key ID**, and **Secret Access Key**

### Step 2 — Update Railway environment variables

```
USE_S3                 = True
AWS_ACCESS_KEY_ID      = your-r2-access-key
AWS_SECRET_ACCESS_KEY  = your-r2-secret-key
AWS_STORAGE_BUCKET_NAME= shopkart-media
AWS_S3_REGION_NAME     = auto
AWS_S3_ENDPOINT_URL    = https://YOUR_ACCOUNT_ID.r2.cloudflarestorage.com
```

Also add this to `config/settings.py` inside the `USE_S3` block:

```python
AWS_S3_ENDPOINT_URL = config('AWS_S3_ENDPOINT_URL', default=None)
```

---

## Part 6 — Add Product Images via Django Admin

1. Go to `https://your-app.up.railway.app/admin`
2. Login with `admin@shopkart.com` / `Admin@1234`
3. Products → select a product → scroll to **Product Images**
4. Upload image → check **Is Primary** for the main image
5. Save

---

## Part 7 — Custom Domain (optional)

### Vercel (frontend)

```
Vercel project → Settings → Domains → Add domain
Add DNS CNAME record at your registrar:
  shopkart.com → cname.vercel-dns.com
```

### Railway (backend)

```
Railway service → Settings → Networking → Custom Domain
Add your API subdomain:
  api.shopkart.com → CNAME → your-app.up.railway.app

Then update ALLOWED_HOSTS and CORS_ALLOWED_ORIGINS in Railway variables.
```

---

## Cost Summary

| Service | Free Tier | Notes |
|---------|-----------|-------|
| Vercel | ✅ Free forever | 100GB bandwidth/month |
| Railway | $5 credit/month | Covers small apps easily |
| Railway PostgreSQL | Included | 1GB storage free |
| Upstash Redis | ✅ Free forever | 10,000 commands/day |
| Cloudflare R2 | ✅ Free forever | 10GB storage, 1M reads/month |
| Stripe | ✅ No monthly fee | 2.9% + 30¢ per transaction |

**Total monthly cost for a portfolio project: $0**

---

## Quick Reference — Useful Commands

```bash
# Backend — generate new secret key
python -c "import secrets; print(secrets.token_urlsafe(50))"

# Run migrations after model changes
python manage.py makemigrations && python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Collect static files
python manage.py collectstatic

# Start celery worker
celery -A config worker --loglevel=info

# Start celery beat (scheduled tasks)
celery -A config beat --loglevel=info

# Check Django config
python manage.py check --deploy
```

---

## Final Folder Structure

```
ecommerce/
├── backend/
│   ├── apps/
│   │   ├── users/          # Auth, JWT, addresses
│   │   ├── products/       # Products, categories, reviews, wishlist
│   │   ├── orders/         # Cart, orders, checkout
│   │   └── payments/       # Stripe webhook, email tasks
│   ├── config/
│   │   ├── settings.py
│   │   ├── urls.py
│   │   ├── celery.py
│   │   └── wsgi.py
│   ├── .env.example
│   ├── Procfile
│   ├── railway.json
│   └── requirements.txt
│
└── frontend/
    ├── src/
    │   ├── api/            # Axios + all API calls
    │   ├── components/
    │   │   ├── layout/     # Navbar, Footer, ProtectedRoute
    │   │   ├── product/    # ProductCard
    │   │   └── cart/       # CartDrawer
    │   ├── pages/          # All 9 pages
    │   ├── store/          # Zustand (auth + cart)
    │   ├── App.jsx
    │   ├── main.jsx
    │   └── index.css
    ├── .env.example
    ├── vercel.json
    └── package.json
```
