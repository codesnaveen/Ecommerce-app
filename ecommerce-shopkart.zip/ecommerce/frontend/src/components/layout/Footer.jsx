import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer style={{
      borderTop: '1px solid var(--border)', background: 'var(--surface)',
      padding: '48px 0 32px', marginTop: '80px'
    }}>
      <div className="container" style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 40 }}>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: 'var(--accent)', marginBottom: 12 }}>ShopKart</div>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', lineHeight: 1.7, maxWidth: 280 }}>
            Curated products at honest prices. Free shipping above ₹999.
          </p>
        </div>
        {[
          { title: 'Shop', links: [['All Products', '/products'], ['Electronics', '/products?category=electronics'], ['Clothing', '/products?category=clothing'], ['Deals', '/products?is_featured=true']] },
          { title: 'Account', links: [['Sign In', '/login'], ['Register', '/register'], ['Orders', '/orders'], ['Wishlist', '/wishlist']] },
          { title: 'Support', links: [['About', '#'], ['Contact', '#'], ['Returns', '#'], ['Shipping', '#']] },
        ].map(col => (
          <div key={col.title}>
            <h4 style={{ fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-light)', marginBottom: 16 }}>{col.title}</h4>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {col.links.map(([label, href]) => (
                <li key={label}><Link to={href} style={{ fontSize: 14, color: 'var(--text-muted)' }}>{label}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="container" style={{ marginTop: 40, paddingTop: 24, borderTop: '1px solid var(--border)', fontSize: 13, color: 'var(--text-light)' }}>
        © {new Date().getFullYear()} ShopKart. Built with React + Django.
      </div>
    </footer>
  )
}
