import { Link, useNavigate } from 'react-router-dom'
import { useAuthStore, useCartStore } from '../../store'
import { useState } from 'react'
import './Navbar.css'

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuthStore()
  const { toggleCart, itemCount } = useCartStore()
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <nav className="navbar">
      <div className="navbar-inner container">
        <Link to="/" className="navbar-logo">ShopKart</Link>

        <div className="navbar-links">
          <Link to="/products" className="nav-link">Shop</Link>
          <Link to="/products?category=electronics" className="nav-link">Electronics</Link>
          <Link to="/products?category=clothing" className="nav-link">Clothing</Link>
          <Link to="/products?is_featured=true" className="nav-link">Deals</Link>
        </div>

        <div className="navbar-actions">
          {isAuthenticated ? (
            <div className="user-menu">
              <button className="user-btn" onClick={() => setMenuOpen(o => !o)}>
                <span className="user-avatar">{user?.first_name?.[0] || user?.email?.[0]}</span>
              </button>
              {menuOpen && (
                <div className="dropdown" onMouseLeave={() => setMenuOpen(false)}>
                  <Link to="/profile" className="dropdown-item" onClick={() => setMenuOpen(false)}>Profile</Link>
                  <Link to="/orders" className="dropdown-item" onClick={() => setMenuOpen(false)}>My Orders</Link>
                  <Link to="/wishlist" className="dropdown-item" onClick={() => setMenuOpen(false)}>Wishlist</Link>
                  <hr className="dropdown-divider" />
                  <button className="dropdown-item danger" onClick={handleLogout}>Sign Out</button>
                </div>
              )}
            </div>
          ) : (
            <Link to="/login" className="nav-link">Sign In</Link>
          )}

          <button className="cart-btn" onClick={toggleCart} aria-label="Open cart">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/>
            </svg>
            {itemCount() > 0 && <span className="cart-badge">{itemCount()}</span>}
          </button>
        </div>
      </div>
    </nav>
  )
}
