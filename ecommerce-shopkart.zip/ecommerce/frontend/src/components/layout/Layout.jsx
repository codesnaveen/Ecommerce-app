import { Outlet } from 'react-router-dom'
import Navbar from './Navbar'
import CartDrawer from '../cart/CartDrawer'
import Footer from './Footer'

export default function Layout() {
  return (
    <>
      <Navbar />
      <CartDrawer />
      <main style={{ minHeight: 'calc(100vh - var(--nav-h))', paddingTop: 'var(--nav-h)' }}>
        <Outlet />
      </main>
      <Footer />
    </>
  )
}
