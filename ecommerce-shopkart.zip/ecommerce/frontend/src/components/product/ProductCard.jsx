import { Link } from 'react-router-dom'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { addToCart } from '../../api'
import { useCartStore } from '../../store'
import toast from 'react-hot-toast'
import './ProductCard.css'

export default function ProductCard({ product }) {
  const { setCart, openCart } = useCartStore()
  const qc = useQueryClient()

  const { mutate, isPending } = useMutation({
    mutationFn: () => addToCart({ product_id: product.id, quantity: 1 }),
    onSuccess: ({ data }) => {
      setCart(data)
      openCart()
      toast.success('Added to cart')
      qc.invalidateQueries(['cart'])
    },
    onError: () => toast.error('Failed to add to cart'),
  })

  const discount = product.discount_percent
  const rating = product.average_rating
  const inStock = product.stock > 0

  return (
    <article className="product-card fade-up">
      <Link to={`/products/${product.slug}`} className="card-image-wrap">
        {product.primary_image ? (
          <img src={product.primary_image} alt={product.name} className="card-image" loading="lazy" />
        ) : (
          <div className="card-image-placeholder">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.3">
              <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>
            </svg>
          </div>
        )}
        {discount > 0 && <span className="badge-discount">-{discount}%</span>}
        {!inStock && <span className="badge-oos">Out of Stock</span>}
      </Link>

      <div className="card-body">
        <p className="card-category">{product.category_name}</p>
        <Link to={`/products/${product.slug}`}>
          <h3 className="card-name">{product.name}</h3>
        </Link>

        {rating > 0 && (
          <div className="card-rating">
            <Stars rating={rating} />
            <span className="rating-count">({product.review_count})</span>
          </div>
        )}

        <div className="card-footer">
          <div className="card-price">
            <span className="price-current">₹{Number(product.price).toLocaleString('en-IN')}</span>
            {product.compare_price && (
              <span className="price-old">₹{Number(product.compare_price).toLocaleString('en-IN')}</span>
            )}
          </div>
          <button
            className="btn-add-cart"
            onClick={() => mutate()}
            disabled={!inStock || isPending}
          >
            {isPending ? '...' : '+'}
          </button>
        </div>
      </div>
    </article>
  )
}

export function Stars({ rating, size = 13 }) {
  return (
    <div style={{ display: 'flex', gap: 2 }}>
      {[1,2,3,4,5].map(i => (
        <svg key={i} width={size} height={size} viewBox="0 0 24 24"
          fill={i <= Math.round(rating) ? '#F59E0B' : 'none'}
          stroke="#F59E0B" strokeWidth="1.5">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
        </svg>
      ))}
    </div>
  )
}
