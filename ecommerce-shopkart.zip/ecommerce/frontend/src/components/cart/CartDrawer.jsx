import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getCart, updateCartItem, removeCartItem } from '../../api'
import { useCartStore } from '../../store'
import './CartDrawer.css'

export default function CartDrawer() {
  const { isOpen, closeCart, setCart } = useCartStore()
  const qc = useQueryClient()

  const { data: cart } = useQuery({
    queryKey: ['cart'],
    queryFn: () => getCart().then(r => r.data),
    onSuccess: (data) => setCart(data),
  })

  const updateMutation = useMutation({
    mutationFn: ({ id, qty }) => updateCartItem(id, { quantity: qty }),
    onSuccess: ({ data }) => { setCart(data); qc.invalidateQueries(['cart']) }
  })

  const removeMutation = useMutation({
    mutationFn: (id) => removeCartItem(id),
    onSuccess: ({ data }) => { setCart(data); qc.invalidateQueries(['cart']) }
  })

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && closeCart()
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [])

  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [isOpen])

  const items = cart?.items || []
  const total = cart?.total || '0.00'

  return (
    <>
      {isOpen && <div className="drawer-overlay" onClick={closeCart} />}
      <aside className={`cart-drawer ${isOpen ? 'open' : ''}`}>
        <div className="drawer-header">
          <h2>Your Cart {items.length > 0 && <span className="drawer-count">{cart?.item_count}</span>}</h2>
          <button className="drawer-close" onClick={closeCart} aria-label="Close">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>

        {items.length === 0 ? (
          <div className="drawer-empty">
            <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.3">
              <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/>
            </svg>
            <p>Your cart is empty</p>
            <Link to="/products" className="btn-primary" onClick={closeCart}>Start Shopping</Link>
          </div>
        ) : (
          <>
            <ul className="drawer-items">
              {items.map(item => (
                <li key={item.id} className="drawer-item">
                  <div className="di-image">
                    {item.product?.primary_image
                      ? <img src={item.product.primary_image} alt={item.product.name} />
                      : <div className="di-placeholder" />}
                  </div>
                  <div className="di-info">
                    <p className="di-name">{item.product?.name}</p>
                    {item.variant_name && <p className="di-variant">{item.variant_name}</p>}
                    <p className="di-price">₹{Number(item.unit_price).toLocaleString('en-IN')}</p>
                    <div className="di-qty">
                      <button onClick={() => updateMutation.mutate({ id: item.id, qty: item.quantity - 1 })} disabled={item.quantity <= 1}>−</button>
                      <span>{item.quantity}</span>
                      <button onClick={() => updateMutation.mutate({ id: item.id, qty: item.quantity + 1 })}>+</button>
                    </div>
                  </div>
                  <div className="di-side">
                    <p className="di-subtotal">₹{Number(item.subtotal).toLocaleString('en-IN')}</p>
                    <button className="di-remove" onClick={() => removeMutation.mutate(item.id)} aria-label="Remove">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/>
                      </svg>
                    </button>
                  </div>
                </li>
              ))}
            </ul>

            <div className="drawer-footer">
              <div className="drawer-subtotal">
                <span>Subtotal</span>
                <span>₹{Number(total).toLocaleString('en-IN')}</span>
              </div>
              <p className="drawer-shipping-note">
                {Number(total) >= 999 ? '✓ Free shipping applied' : `Add ₹${(999 - Number(total)).toFixed(0)} more for free shipping`}
              </p>
              <Link to="/checkout" className="btn-primary btn-full" onClick={closeCart}>
                Checkout →
              </Link>
              <Link to="/cart" className="btn-ghost btn-full" onClick={closeCart}>View Cart</Link>
            </div>
          </>
        )}
      </aside>
    </>
  )
}
