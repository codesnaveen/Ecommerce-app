import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  headers: { 'Content-Type': 'application/json' },
})

api.interceptors.request.use(config => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  res => res,
  async err => {
    const original = err.config
    if (err.response?.status === 401 && !original._retry) {
      original._retry = true
      const refresh = localStorage.getItem('refresh_token')
      if (refresh) {
        try {
          const { data } = await axios.post('/api/auth/token/refresh/', { refresh })
          localStorage.setItem('access_token', data.access)
          original.headers.Authorization = `Bearer ${data.access}`
          return api(original)
        } catch {
          localStorage.removeItem('access_token')
          localStorage.removeItem('refresh_token')
          window.location.href = '/login'
        }
      }
    }
    return Promise.reject(err)
  }
)

export default api

// Products
export const getProducts = (params) => api.get('/products/', { params })
export const getProduct = (slug) => api.get(`/products/${slug}/`)
export const getFeatured = () => api.get('/products/featured/')
export const getCategories = () => api.get('/products/categories/')
export const getReviews = (slug) => api.get(`/products/${slug}/reviews/`)
export const addReview = (slug, data) => api.post(`/products/${slug}/reviews/`, data)

// Cart
export const getCart = () => api.get('/orders/cart/')
export const addToCart = (data) => api.post('/orders/cart/add/', data)
export const updateCartItem = (id, data) => api.patch(`/orders/cart/items/${id}/`, data)
export const removeCartItem = (id) => api.delete(`/orders/cart/items/${id}/`)

// Orders
export const checkout = (data) => api.post('/orders/checkout/', data)
export const getOrders = () => api.get('/orders/')
export const getOrder = (id) => api.get(`/orders/${id}/`)

// Auth
export const login = (data) => api.post('/auth/login/', data)
export const register = (data) => api.post('/auth/register/', data)
export const getProfile = () => api.get('/auth/profile/')
export const updateProfile = (data) => api.patch('/auth/profile/', data)

// Wishlist
export const getWishlist = () => api.get('/products/wishlist/')
export const addToWishlist = (product_id) => api.post('/products/wishlist/', { product_id })
export const removeFromWishlist = (id) => api.delete(`/products/wishlist/${id}/`)

// Payments
export const getPaymentConfig = () => api.get('/payments/config/')
