import { useState, useCallback } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getProducts, getCategories } from '../api'
import ProductCard from '../components/product/ProductCard'
import './ProductsPage.css'

export default function ProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [search, setSearch] = useState(searchParams.get('search') || '')

  const params = Object.fromEntries(searchParams.entries())

  const { data, isLoading } = useQuery({
    queryKey: ['products', params],
    queryFn: () => getProducts(params).then(r => r.data),
    keepPreviousData: true,
  })

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: () => getCategories().then(r => r.data)
  })

  const setParam = (key, val) => {
    const next = new URLSearchParams(searchParams)
    if (val) next.set(key, val); else next.delete(key)
    next.delete('page')
    setSearchParams(next)
  }

  const handleSearch = (e) => {
    e.preventDefault()
    setParam('search', search)
  }

  const products = data?.results || []
  const total = data?.count || 0
  const currentPage = parseInt(searchParams.get('page') || '1')
  const totalPages = Math.ceil(total / 12)

  return (
    <div className="container products-page">
      <div className="products-layout">
        {/* Sidebar */}
        <aside className="filter-sidebar">
          <div className="filter-section">
            <h3 className="filter-title">Categories</h3>
            <ul className="filter-list">
              <li>
                <button
                  className={`filter-item ${!searchParams.get('category') ? 'active' : ''}`}
                  onClick={() => setParam('category', '')}
                >All Categories</button>
              </li>
              {categories?.map(cat => (
                <li key={cat.id}>
                  <button
                    className={`filter-item ${searchParams.get('category') === cat.slug ? 'active' : ''}`}
                    onClick={() => setParam('category', cat.slug)}
                  >{cat.name}</button>
                </li>
              ))}
            </ul>
          </div>

          <div className="filter-section">
            <h3 className="filter-title">Price Range</h3>
            <div className="price-inputs">
              <input
                type="number" placeholder="Min ₹"
                value={searchParams.get('min_price') || ''}
                onChange={e => setParam('min_price', e.target.value)}
              />
              <span>–</span>
              <input
                type="number" placeholder="Max ₹"
                value={searchParams.get('max_price') || ''}
                onChange={e => setParam('max_price', e.target.value)}
              />
            </div>
          </div>

          <div className="filter-section">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={searchParams.get('in_stock') === 'true'}
                onChange={e => setParam('in_stock', e.target.checked ? 'true' : '')}
              />
              In Stock Only
            </label>
            <label className="checkbox-label" style={{ marginTop: 10 }}>
              <input
                type="checkbox"
                checked={searchParams.get('is_featured') === 'true'}
                onChange={e => setParam('is_featured', e.target.checked ? 'true' : '')}
              />
              Featured / On Sale
            </label>
          </div>

          <button className="clear-filters" onClick={() => setSearchParams({})}>
            Clear all filters
          </button>
        </aside>

        {/* Main */}
        <div className="products-main">
          <div className="products-toolbar">
            <form onSubmit={handleSearch} className="search-form">
              <input
                type="text" placeholder="Search products..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
              <button type="submit">Search</button>
            </form>
            <div className="sort-wrap">
              <select
                value={searchParams.get('ordering') || '-created_at'}
                onChange={e => setParam('ordering', e.target.value)}
              >
                <option value="-created_at">Newest</option>
                <option value="price">Price: Low to High</option>
                <option value="-price">Price: High to Low</option>
                <option value="name">Name A–Z</option>
              </select>
            </div>
          </div>

          <p className="products-count">
            {isLoading ? 'Loading…' : `${total} product${total !== 1 ? 's' : ''} found`}
          </p>

          {isLoading ? (
            <div className="products-grid">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="skeleton" style={{ height: 320 }} />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="no-results">
              <p>No products match your filters.</p>
              <button onClick={() => setSearchParams({})}>Reset filters</button>
            </div>
          ) : (
            <div className="products-grid">
              {products.map((p, i) => (
                <div key={p.id} style={{ animationDelay: `${i * 0.04}s` }}>
                  <ProductCard product={p} />
                </div>
              ))}
            </div>
          )}

          {totalPages > 1 && (
            <div className="pagination">
              <button
                onClick={() => setParam('page', currentPage - 1)}
                disabled={currentPage <= 1}
              >← Prev</button>
              <span>Page {currentPage} of {totalPages}</span>
              <button
                onClick={() => setParam('page', currentPage + 1)}
                disabled={currentPage >= totalPages}
              >Next →</button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
