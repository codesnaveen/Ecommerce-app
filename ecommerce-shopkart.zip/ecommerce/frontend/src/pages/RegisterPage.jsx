import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { register } from '../api'
import toast from 'react-hot-toast'
import './AuthPages.css'

export default function RegisterPage() {
  const [form, setForm] = useState({ email: '', username: '', first_name: '', last_name: '', password: '', password2: '' })
  const navigate = useNavigate()

  const { mutate, isPending } = useMutation({
    mutationFn: () => register(form),
    onSuccess: () => {
      toast.success('Account created! Please sign in.')
      navigate('/login')
    },
    onError: (err) => {
      const errors = err.response?.data
      if (errors) {
        const msg = Object.values(errors).flat().join(' ')
        toast.error(msg)
      } else {
        toast.error('Registration failed.')
      }
    }
  })

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">ShopKart</div>
        <h1 className="auth-title">Create account</h1>
        <p className="auth-sub">Start shopping in seconds</p>

        <div className="auth-form">
          <div className="field-row">
            <div className="field">
              <label>First Name</label>
              <input type="text" placeholder="John" value={form.first_name} onChange={set('first_name')} />
            </div>
            <div className="field">
              <label>Last Name</label>
              <input type="text" placeholder="Doe" value={form.last_name} onChange={set('last_name')} />
            </div>
          </div>
          <div className="field">
            <label>Email</label>
            <input type="email" placeholder="you@example.com" value={form.email} onChange={set('email')} />
          </div>
          <div className="field">
            <label>Username</label>
            <input type="text" placeholder="johndoe" value={form.username} onChange={set('username')} />
          </div>
          <div className="field">
            <label>Password</label>
            <input type="password" placeholder="Min 8 characters" value={form.password} onChange={set('password')} />
          </div>
          <div className="field">
            <label>Confirm Password</label>
            <input type="password" placeholder="Repeat password" value={form.password2} onChange={set('password2')} />
          </div>
          <button className="auth-submit" onClick={() => mutate()} disabled={isPending}>
            {isPending ? 'Creating account…' : 'Create Account'}
          </button>
        </div>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Sign in →</Link>
        </p>
      </div>
    </div>
  )
}
