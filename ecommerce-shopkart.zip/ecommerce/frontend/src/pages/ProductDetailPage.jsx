import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getProduct, addToCart, addReview } from '../api'
import { useCartStore, useAuthStore } from '../store'
import { Stars } from '../components/product/ProductCard'
import toast from 'react-hot-toast'
import './ProductDetailPage.css'

export default function ProductDetailPage() {
  const { slug } = useParams()
  const { setCart, openCart } = useCartStore()
  const { isAuthenticated } = useAuthStore()
  const qc = useQueryClient()
  const [activeImage, setActiveImage] = useState(0)
  const [qty, setQty] = useState(1)
  const [reviewForm, setReviewForm] = useState({ rating: 5, title: '', body: '' })
  const [showReviewForm, setShowReviewForm] = useState(false)

  const { data: product, isLoading } = useQuery({
    queryKey: ['product', slug],
    queryFn: () => getProduct(slug).then(r => r.data)
  })

  const cartMutation = useMutation({
    mutationFn: () => addToCart({ product_id: product.id, quantity: qty }),
    onSuccess: ({ data }) => { setCart(data); openCart(); toast.success('Added to cart') },
    onError: () => toast.error('Failed to add to cart')
  })

  const reviewMutation = useMutation({
    mutationFn: () => addReview(slug, reviewForm),
    onSuccess: () => {
      toast.success('Review submitted!')
      setShowReviewForm(false)
      qc.invalidateQueries(['product', slug])
    },
    onError: () => toast.error('Could not submit review. Already reviewed?')
  })

  if (isLoading) return (
    <div className="container" style={{ padding: '60px 24px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40 }}>
        <div className="skeleton" style={{ height: 480 }} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {[80, 40, 120, 48, 48].map((h, i) => <div key={i} className="skeleton" style={{ height: h }} />)}
        </div>
      </div>
    </div>
  )

  if (!product) return <div className="container" style={{ padding: 60 }}>Product not found.</div>

  const images = product.images || []
  const activeImg = images[activeImage]

  return (
    <div className="container product-detail-page">
      <div className="breadcrumb">
        <Link to="/">Home</Link> / <Link to="/products">Products</Link> / <span>{product.name}</span>
      </div>

      <div className="detail-layout">
        {/* Gallery */}
        <div className="gallery">
          <div className="gallery-main">
            {activeImg
              ? <img src={activeImg.image} alt={activeImg.alt_text || product.name} />
              : <div className="gallery-placeholder"><span>No image</span></div>
            }
            {product.discount_percent > 0 && (
              <span className="detail-badge">-{product.discount_percent}%</span>
            )}
          </div>
          {images.length > 1 && (
            <div className="gallery-thumbs">
              {images.map((img, i) => (
                <button
                  key={img.id}
                  className={`gallery-thumb ${i === activeImage ? 'active' : ''}`}
                  onClick={() => setActiveImage(i)}
                >
                  <img src={img.image} alt={img.alt_text} />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div className="detail-info fade-up">
          {product.category && <p className="detail-category">{product.category.name}</p>}
          <h1 className="detail-name">{product.name}</h1>

          {product.average_rating > 0 && (
            <div className="detail-rating">
              <Stars rating={product.average_rating} size={16} />
              <span>{product.average_rating} ({product.review_count} reviews)</span>
            </div>
          )}

          <div className="detail-price">
            <span className="dp-current">₹{Number(product.price).toLocaleString('en-IN')}</span>
            {product.compare_price && (
              <span className="dp-old">₹{Number(product.compare_price).toLocaleString('en-IN')}</span>
            )}
          </div>

          <p className="detail-description">{product.description}</p>

          <div className="detail-stock">
            {product.stock > 0
              ? <span className="in-stock">✓ In Stock ({product.stock} available)</span>
              : <span className="out-stock">✗ Out of Stock</span>
            }
          </div>

          {product.stock > 0 && (
            <div className="detail-actions">
              <div className="qty-selector">
                <button onClick={() => setQty(q => Math.max(1, q - 1))}>−</button>
                <span>{qty}</span>
                <button onClick={() => setQty(q => Math.min(product.stock, q + 1))}>+</button>
              </div>
              <button
                className="btn-detail-cart"
                onClick={() => cartMutation.mutate()}
                disabled={cartMutation.isPending}
              >
                {cartMutation.isPending ? 'Adding…' : 'Add to Cart'}
              </button>
            </div>
          )}

          <div className="detail-meta">
            {product.sku && <div className="meta-row"><span>SKU</span><span>{product.sku}</span></div>}
            {product.weight && <div className="meta-row"><span>Weight</span><span>{product.weight} kg</span></div>}
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="reviews-section">
        <div className="reviews-header">
          <h2>Customer Reviews</h2>
          {isAuthenticated && !showReviewForm && (
            <button className="btn-write-review" onClick={() => setShowReviewForm(true)}>
              Write a Review
            </button>
          )}
        </div>

        {showReviewForm && (
          <div className="review-form">
            <h3>Your Review</h3>
            <div className="form-field">
              <label>Rating</label>
              <select value={reviewForm.rating} onChange={e => setReviewForm(f => ({ ...f, rating: Number(e.target.value) }))}>
                {[5,4,3,2,1].map(r => <option key={r} value={r}>{'★'.repeat(r)} {r}/5</option>)}
              </select>
            </div>
            <div className="form-field">
              <label>Title</label>
              <input type="text" placeholder="Summary of your experience"
                value={reviewForm.title}
                onChange={e => setReviewForm(f => ({ ...f, title: e.target.value }))} />
            </div>
            <div className="form-field">
              <label>Review</label>
              <textarea rows={4} placeholder="Tell others what you think..."
                value={reviewForm.body}
                onChange={e => setReviewForm(f => ({ ...f, body: e.target.value }))} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn-submit-review" onClick={() => reviewMutation.mutate()} disabled={reviewMutation.isPending}>
                {reviewMutation.isPending ? 'Submitting…' : 'Submit Review'}
              </button>
              <button className="btn-cancel-review" onClick={() => setShowReviewForm(false)}>Cancel</button>
            </div>
          </div>
        )}

        {product.reviews?.length > 0 ? (
          <div className="reviews-list">
            {product.reviews.map(review => (
              <div key={review.id} className="review-card">
                <div className="review-top">
                  <div className="reviewer-avatar">{review.user_name[0]}</div>
                  <div>
                    <p className="reviewer-name">{review.user_name}</p>
                    <Stars rating={review.rating} size={12} />
                  </div>
                  <span className="review-date">{new Date(review.created_at).toLocaleDateString('en-IN')}</span>
                </div>
                {review.title && <p className="review-title">{review.title}</p>}
                <p className="review-body">{review.body}</p>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ color: 'var(--text-light)', padding: '24px 0' }}>No reviews yet. Be the first!</p>
        )}
      </section>
    </div>
  )
}
