import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getFeatured, getCategories } from '../api'
import ProductCard from '../components/product/ProductCard'
import './HomePage.css'

export default function HomePage() {
  const { data: featured } = useQuery({
    queryKey: ['featured'],
    queryFn: () => getFeatured().then(r => r.data.results || r.data)
  })
  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: () => getCategories().then(r => r.data)
  })

  return (
    <div>
      {/* Hero */}
      <section className="hero">
        <div className="container hero-inner">
          <div className="hero-content fade-up">
            <p className="hero-eyebrow">New arrivals · Free shipping ₹999+</p>
            <h1 className="hero-title">Quality things,<br /><em>honestly priced.</em></h1>
            <p className="hero-sub">Curated electronics, clothing, books and more — shipped across India.</p>
            <div className="hero-cta">
              <Link to="/products" className="btn-hero-primary">Shop Now →</Link>
              <Link to="/products?is_featured=true" className="btn-hero-ghost">View Deals</Link>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-blob" />
            <div className="hero-card-stack">
              {[
                { emoji: '🎧', name: 'Headphones', price: '₹8,999' },
                { emoji: '👕', name: 'Cotton Tee', price: '₹599' },
                { emoji: '📚', name: 'Atomic Habits', price: '₹499' },
              ].map((item, i) => (
                <div key={i} className={`hero-mini-card hc-${i}`}>
                  <span>{item.emoji}</span>
                  <div>
                    <p>{item.name}</p>
                    <p className="hmc-price">{item.price}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      {categories?.length > 0 && (
        <section className="section container">
          <h2 className="section-title">Browse by category</h2>
          <div className="categories-grid">
            {categories.map(cat => (
              <Link key={cat.id} to={`/products?category=${cat.slug}`} className="category-chip">
                {cat.name}
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Featured products */}
      <section className="section container">
        <div className="section-header">
          <h2 className="section-title">Featured picks</h2>
          <Link to="/products?is_featured=true" className="section-link">View all →</Link>
        </div>
        {featured ? (
          <div className="products-grid">
            {featured.slice(0, 8).map((p, i) => (
              <div key={p.id} style={{ animationDelay: `${i * 0.06}s` }}>
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        ) : (
          <div className="products-grid">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="skeleton" style={{ height: 320 }} />
            ))}
          </div>
        )}
      </section>

      {/* Banner */}
      <section className="banner container">
        <div className="banner-inner">
          <div>
            <h3 className="banner-title">Free shipping on orders above ₹999</h3>
            <p className="banner-sub">Pan-India delivery · Easy 30-day returns · Secure payments</p>
          </div>
          <Link to="/products" className="btn-banner">Shop Now</Link>
        </div>
      </section>
    </div>
  )
}
