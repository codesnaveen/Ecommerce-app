import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery, useMutation } from '@tanstack/react-query'
import { loadStripe } from '@stripe/stripe-js'
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js'
import { getCart, checkout, getPaymentConfig } from '../api'
import { useAuthStore } from '../store'
import toast from 'react-hot-toast'
import './CheckoutPage.css'

let stripePromise = null
const getStripe = (key) => {
  if (!stripePromise) stripePromise = loadStripe(key)
  return stripePromise
}

export default function CheckoutPage() {
  const { data: config } = useQuery({
    queryKey: ['payment-config'],
    queryFn: () => getPaymentConfig().then(r => r.data)
  })

  if (!config) return <div className="container checkout-loading">Loading checkout…</div>

  return (
    <Elements stripe={getStripe(config.publishable_key)} options={{ appearance: { theme: 'stripe' } }}>
      <CheckoutInner />
    </Elements>
  )
}

function CheckoutInner() {
  const { user } = useAuthStore()
  const navigate = useNavigate()
  const stripe = useStripe()
  const elements = useElements()
  const [step, setStep] = useState(1) // 1: shipping, 2: payment
  const [clientSecret, setClientSecret] = useState('')
  const [orderId, setOrderId] = useState(null)
  const [processing, setProcessing] = useState(false)

  const [shipping, setShipping] = useState({
    shipping_name: `${user?.first_name || ''} ${user?.last_name || ''}`.trim(),
    shipping_line1: '', shipping_line2: '',
    shipping_city: '', shipping_state: '',
    shipping_postal_code: '', shipping_country: 'IN',
    shipping_phone: user?.phone || '',
  })

  const { data: cart } = useQuery({
    queryKey: ['cart'],
    queryFn: () => getCart().then(r => r.data)
  })

  const checkoutMutation = useMutation({
    mutationFn: () => checkout(shipping),
    onSuccess: ({ data }) => {
      setClientSecret(data.client_secret)
      setOrderId(data.order_id)
      setStep(2)
      if (elements) elements.fetchUpdates()
    },
    onError: (err) => toast.error(err.response?.data?.error || 'Checkout failed.')
  })

  const handlePayment = async () => {
    if (!stripe || !elements || !clientSecret) return
    setProcessing(true)
    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: { return_url: `${window.location.origin}/orders/${orderId}` },
      redirect: 'if_required',
    })
    if (error) {
      toast.error(error.message)
      setProcessing(false)
    } else {
      toast.success('Payment successful!')
      navigate(`/orders/${orderId}`)
    }
  }

  const setField = (k) => (e) => setShipping(s => ({ ...s, [k]: e.target.value }))

  const items = cart?.items || []
  const subtotal = Number(cart?.total || 0)
  const shipping_cost = subtotal >= 999 ? 0 : 99
  const tax = (subtotal * 0.18).toFixed(2)
  const total = (subtotal + shipping_cost + Number(tax)).toFixed(2)

  return (
    <div className="checkout-page container">
      <h1 className="checkout-title">Checkout</h1>

      <div className="checkout-layout">
        <div className="checkout-left">
          {/* Steps */}
          <div className="checkout-steps">
            <div className={`step ${step >= 1 ? 'active' : ''}`}>
              <span className="step-num">1</span>
              <span>Shipping</span>
            </div>
            <div className="step-line" />
            <div className={`step ${step >= 2 ? 'active' : ''}`}>
              <span className="step-num">2</span>
              <span>Payment</span>
            </div>
          </div>

          {step === 1 && (
            <div className="checkout-form fade-up">
              <h2>Shipping Address</h2>
              <div className="form-grid">
                <div className="field full">
                  <label>Full Name</label>
                  <input value={shipping.shipping_name} onChange={setField('shipping_name')} placeholder="John Doe" />
                </div>
                <div className="field full">
                  <label>Address Line 1</label>
                  <input value={shipping.shipping_line1} onChange={setField('shipping_line1')} placeholder="123 Main Street" />
                </div>
                <div className="field full">
                  <label>Address Line 2 (optional)</label>
                  <input value={shipping.shipping_line2} onChange={setField('shipping_line2')} placeholder="Apartment, suite, etc." />
                </div>
                <div className="field">
                  <label>City</label>
                  <input value={shipping.shipping_city} onChange={setField('shipping_city')} placeholder="Hyderabad" />
                </div>
                <div className="field">
                  <label>State</label>
                  <input value={shipping.shipping_state} onChange={setField('shipping_state')} placeholder="Telangana" />
                </div>
                <div className="field">
                  <label>Postal Code</label>
                  <input value={shipping.shipping_postal_code} onChange={setField('shipping_postal_code')} placeholder="500001" />
                </div>
                <div className="field">
                  <label>Phone</label>
                  <input value={shipping.shipping_phone} onChange={setField('shipping_phone')} placeholder="+91 9999999999" />
                </div>
              </div>
              <button
                className="checkout-btn"
                onClick={() => checkoutMutation.mutate()}
                disabled={checkoutMutation.isPending || !shipping.shipping_line1 || !shipping.shipping_city}
              >
                {checkoutMutation.isPending ? 'Processing…' : 'Continue to Payment →'}
              </button>
            </div>
          )}

          {step === 2 && clientSecret && (
            <div className="checkout-form fade-up">
              <h2>Payment Details</h2>
              <p className="stripe-note">Powered by Stripe. Test card: 4242 4242 4242 4242</p>
              <Elements stripe={stripe} options={{ clientSecret, appearance: { theme: 'stripe' } }}>
                <PaymentElementForm onPay={handlePayment} processing={processing} />
              </Elements>
            </div>
          )}
        </div>

        {/* Order summary */}
        <div className="order-summary">
          <h2>Order Summary</h2>
          <ul className="summary-items">
            {items.map(item => (
              <li key={item.id} className="summary-item">
                <span className="si-name">{item.product?.name} × {item.quantity}</span>
                <span className="si-price">₹{Number(item.subtotal).toLocaleString('en-IN')}</span>
              </li>
            ))}
          </ul>
          <div className="summary-totals">
            <div className="total-row"><span>Subtotal</span><span>₹{subtotal.toLocaleString('en-IN')}</span></div>
            <div className="total-row"><span>Shipping</span><span>{shipping_cost === 0 ? 'Free' : `₹${shipping_cost}`}</span></div>
            <div className="total-row"><span>GST (18%)</span><span>₹{Number(tax).toLocaleString('en-IN')}</span></div>
            <div className="total-row total-final"><span>Total</span><span>₹{Number(total).toLocaleString('en-IN')}</span></div>
          </div>
        </div>
      </div>
    </div>
  )
}

function PaymentElementForm({ onPay, processing }) {
  const stripe = useStripe()
  const elements = useElements()
  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <PaymentElement />
      </div>
      <button className="checkout-btn" onClick={onPay} disabled={!stripe || !elements || processing}>
        {processing ? 'Processing payment…' : 'Pay Now →'}
      </button>
    </div>
  )
}
