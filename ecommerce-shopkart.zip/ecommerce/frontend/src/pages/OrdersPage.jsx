import { Link, useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getOrders, getOrder } from '../api'
import './OrdersPage.css'

const STATUS_COLOR = {
  pending: '#F59E0B', confirmed: '#3B82F6', processing: '#8B5CF6',
  shipped: '#06B6D4', delivered: '#10B981', cancelled: '#EF4444', refunded: '#6B7280'
}

export default function OrdersPage() {
  const { data: orders, isLoading } = useQuery({
    queryKey: ['orders'],
    queryFn: () => getOrders().then(r => r.data.results || r.data)
  })

  return (
    <div className="container orders-page">
      <h1 className="orders-title">My Orders</h1>
      {isLoading ? (
        <div className="orders-list">{[...Array(3)].map((_, i) => <div key={i} className="skeleton" style={{ height: 120 }} />)}</div>
      ) : !orders?.length ? (
        <div className="orders-empty">
          <p>You haven't placed any orders yet.</p>
          <Link to="/products" className="btn-shop-now">Start Shopping →</Link>
        </div>
      ) : (
        <div className="orders-list">
          {orders.map(order => (
            <Link key={order.id} to={`/orders/${order.id}`} className="order-card fade-up">
              <div className="oc-header">
                <div>
                  <p className="oc-number">{order.order_number}</p>
                  <p className="oc-date">{new Date(order.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                </div>
                <span className="oc-status" style={{ background: STATUS_COLOR[order.status] + '18', color: STATUS_COLOR[order.status] }}>
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                </span>
              </div>
              <div className="oc-body">
                <div className="oc-items">
                  {order.items?.slice(0, 3).map(item => (
                    <span key={item.id} className="oc-item-chip">{item.product_name} ×{item.quantity}</span>
                  ))}
                  {order.items?.length > 3 && <span className="oc-item-chip">+{order.items.length - 3} more</span>}
                </div>
                <div className="oc-total">
                  <span className="oc-total-label">Total</span>
                  <span className="oc-total-value">₹{Number(order.total).toLocaleString('en-IN')}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}

export function OrderSuccessPage() {
  const { id } = useParams()
  const { data: order, isLoading } = useQuery({
    queryKey: ['order', id],
    queryFn: () => getOrder(id).then(r => r.data)
  })

  if (isLoading) return <div className="container orders-page"><p>Loading order…</p></div>
  if (!order) return <div className="container orders-page"><p>Order not found.</p></div>

  const isPaid = order.payment_status === 'paid'

  return (
    <div className="container order-success-page">
      <div className="success-hero">
        <div className={`success-icon ${isPaid ? 'paid' : 'pending'}`}>
          {isPaid ? '✓' : '⏳'}
        </div>
        <h1>{isPaid ? 'Order Confirmed!' : 'Order Placed'}</h1>
        <p>{isPaid ? 'Your payment was successful. We\'ll email you when it ships.' : 'Payment pending. Complete checkout if needed.'}</p>
      </div>

      <div className="success-card">
        <div className="success-meta">
          <div className="sm-item">
            <span>Order Number</span>
            <strong>{order.order_number}</strong>
          </div>
          <div className="sm-item">
            <span>Date</span>
            <strong>{new Date(order.created_at).toLocaleDateString('en-IN')}</strong>
          </div>
          <div className="sm-item">
            <span>Status</span>
            <strong style={{ color: STATUS_COLOR[order.status] }}>{order.status.charAt(0).toUpperCase() + order.status.slice(1)}</strong>
          </div>
          <div className="sm-item">
            <span>Payment</span>
            <strong>{order.payment_status === 'paid' ? '✓ Paid' : order.payment_status}</strong>
          </div>
        </div>

        <div className="success-section">
          <h3>Items Ordered</h3>
          <div className="success-items">
            {order.items?.map(item => (
              <div key={item.id} className="success-item">
                <div className="si-details">
                  <p className="si-name">{item.product_name}</p>
                  {item.variant_name && <p className="si-var">{item.variant_name}</p>}
                  <p className="si-qty">Qty: {item.quantity}</p>
                </div>
                <span className="si-amt">₹{Number(item.subtotal).toLocaleString('en-IN')}</span>
              </div>
            ))}
          </div>
          <div className="success-totals">
            <div className="st-row"><span>Subtotal</span><span>₹{Number(order.subtotal).toLocaleString('en-IN')}</span></div>
            <div className="st-row"><span>Shipping</span><span>{Number(order.shipping_cost) === 0 ? 'Free' : `₹${Number(order.shipping_cost).toLocaleString('en-IN')}`}</span></div>
            <div className="st-row"><span>GST</span><span>₹{Number(order.tax).toLocaleString('en-IN')}</span></div>
            <div className="st-row st-final"><span>Total</span><span>₹{Number(order.total).toLocaleString('en-IN')}</span></div>
          </div>
        </div>

        <div className="success-section">
          <h3>Shipping To</h3>
          <address className="success-address">
            <strong>{order.shipping_name}</strong><br />
            {order.shipping_line1}{order.shipping_line2 && `, ${order.shipping_line2}`}<br />
            {order.shipping_city}, {order.shipping_state} {order.shipping_postal_code}<br />
            {order.shipping_country}
          </address>
        </div>
      </div>

      <div className="success-actions">
        <Link to="/orders" className="btn-all-orders">View All Orders</Link>
        <Link to="/products" className="btn-keep-shopping">Keep Shopping →</Link>
      </div>
    </div>
  )
}
