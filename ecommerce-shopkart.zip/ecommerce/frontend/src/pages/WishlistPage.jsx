import { Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getWishlist, removeFromWishlist, addToCart } from '../api'
import { useCartStore } from '../store'
import { Stars } from '../components/product/ProductCard'
import toast from 'react-hot-toast'
import './WishlistPage.css'

export default function WishlistPage() {
  const { setCart, openCart } = useCartStore()
  const qc = useQueryClient()

  const { data: items, isLoading } = useQuery({
    queryKey: ['wishlist'],
    queryFn: () => getWishlist().then(r => r.data.results || r.data)
  })

  const removeMutation = useMutation({
    mutationFn: (id) => removeFromWishlist(id),
    onSuccess: () => { qc.invalidateQueries(['wishlist']); toast.success('Removed from wishlist') }
  })

  const cartMutation = useMutation({
    mutationFn: (productId) => addToCart({ product_id: productId, quantity: 1 }),
    onSuccess: ({ data }) => { setCart(data); openCart(); toast.success('Added to cart'); qc.invalidateQueries(['cart']) }
  })

  return (
    <div className="container wishlist-page">
      <h1 className="wishlist-title">My Wishlist</h1>

      {isLoading ? (
        <div className="wl-grid">{[...Array(4)].map((_, i) => <div key={i} className="skeleton" style={{ height: 300 }} />)}</div>
      ) : !items?.length ? (
        <div className="wl-empty">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.3">
            <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
          </svg>
          <h2>Your wishlist is empty</h2>
          <p>Save items you love by clicking the heart icon on any product.</p>
          <Link to="/products" className="btn-browse">Browse Products →</Link>
        </div>
      ) : (
        <>
          <p className="wl-count">{items.length} saved item{items.length !== 1 ? 's' : ''}</p>
          <div className="wl-grid">
            {items.map(item => {
              const p = item.product
              return (
                <div key={item.id} className="wl-card fade-up">
                  <Link to={`/products/${p.slug}`} className="wl-image">
                    {p.primary_image
                      ? <img src={p.primary_image} alt={p.name} />
                      : <div className="wl-img-placeholder" />}
                    {p.discount_percent > 0 && <span className="wl-badge">-{p.discount_percent}%</span>}
                  </Link>
                  <div className="wl-info">
                    <p className="wl-category">{p.category_name}</p>
                    <Link to={`/products/${p.slug}`} className="wl-name">{p.name}</Link>
                    {p.average_rating > 0 && (
                      <div className="wl-rating"><Stars rating={p.average_rating} size={12} /><span>({p.review_count})</span></div>
                    )}
                    <div className="wl-price">
                      <span className="wl-current">₹{Number(p.price).toLocaleString('en-IN')}</span>
                      {p.compare_price && <span className="wl-old">₹{Number(p.compare_price).toLocaleString('en-IN')}</span>}
                    </div>
                    <div className="wl-actions">
                      <button
                        className="btn-wl-cart"
                        onClick={() => cartMutation.mutate(p.id)}
                        disabled={!p.stock || cartMutation.isPending}
                      >
                        {p.stock ? 'Add to Cart' : 'Out of Stock'}
                      </button>
                      <button className="btn-wl-remove" onClick={() => removeMutation.mutate(item.id)} title="Remove">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}
