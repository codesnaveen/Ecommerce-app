import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getProfile, updateProfile } from '../api'
import { useAuthStore } from '../store'
import toast from 'react-hot-toast'
import './ProfilePage.css'

export default function ProfilePage() {
  const { setUser } = useAuthStore()
  const qc = useQueryClient()

  const { data: profile } = useQuery({
    queryKey: ['profile'],
    queryFn: () => getProfile().then(r => r.data)
  })

  const [form, setForm] = useState(null)
  const [editing, setEditing] = useState(false)

  const startEdit = () => {
    setForm({
      first_name: profile?.first_name || '',
      last_name: profile?.last_name || '',
      phone: profile?.phone || '',
      username: profile?.username || '',
    })
    setEditing(true)
  }

  const { mutate, isPending } = useMutation({
    mutationFn: () => updateProfile(form),
    onSuccess: ({ data }) => {
      setUser(data)
      qc.invalidateQueries(['profile'])
      toast.success('Profile updated!')
      setEditing(false)
    },
    onError: () => toast.error('Failed to update profile.')
  })

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  if (!profile) return <div className="container profile-page"><p>Loading…</p></div>

  return (
    <div className="container profile-page">
      <h1 className="profile-title">My Profile</h1>

      <div className="profile-layout">
        <div className="profile-card">
          <div className="profile-avatar">
            {profile.first_name?.[0] || profile.email?.[0]}
          </div>
          <div className="profile-name">
            {profile.first_name} {profile.last_name}
          </div>
          <div className="profile-email">{profile.email}</div>
          {profile.is_seller && <span className="seller-badge">Seller Account</span>}
          <p className="profile-since">
            Member since {new Date(profile.created_at).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}
          </p>
        </div>

        <div className="profile-details">
          {!editing ? (
            <>
              <div className="pd-header">
                <h2>Personal Information</h2>
                <button className="btn-edit" onClick={startEdit}>Edit</button>
              </div>
              <div className="pd-grid">
                <div className="pd-field"><label>First Name</label><p>{profile.first_name || '—'}</p></div>
                <div className="pd-field"><label>Last Name</label><p>{profile.last_name || '—'}</p></div>
                <div className="pd-field"><label>Email</label><p>{profile.email}</p></div>
                <div className="pd-field"><label>Username</label><p>{profile.username}</p></div>
                <div className="pd-field"><label>Phone</label><p>{profile.phone || '—'}</p></div>
              </div>
            </>
          ) : (
            <>
              <div className="pd-header">
                <h2>Edit Profile</h2>
                <button className="btn-cancel" onClick={() => setEditing(false)}>Cancel</button>
              </div>
              {form && (
                <div className="edit-form">
                  <div className="edit-grid">
                    <div className="field">
                      <label>First Name</label>
                      <input value={form.first_name} onChange={set('first_name')} />
                    </div>
                    <div className="field">
                      <label>Last Name</label>
                      <input value={form.last_name} onChange={set('last_name')} />
                    </div>
                    <div className="field full">
                      <label>Username</label>
                      <input value={form.username} onChange={set('username')} />
                    </div>
                    <div className="field full">
                      <label>Phone</label>
                      <input value={form.phone} onChange={set('phone')} placeholder="+91 9999999999" />
                    </div>
                  </div>
                  <button className="btn-save" onClick={() => mutate()} disabled={isPending}>
                    {isPending ? 'Saving…' : 'Save Changes'}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
