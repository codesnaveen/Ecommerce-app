import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { login } from '../api'
import { useAuthStore } from '../store'
import toast from 'react-hot-toast'
import './AuthPages.css'

export default function LoginPage() {
  const [form, setForm] = useState({ email: '', password: '' })
  const { setUser } = useAuthStore()
  const navigate = useNavigate()
  const location = useLocation()
  const from = location.state?.from || '/'

  const { mutate, isPending } = useMutation({
    mutationFn: () => login(form),
    onSuccess: ({ data }) => {
      localStorage.setItem('access_token', data.access)
      localStorage.setItem('refresh_token', data.refresh)
      setUser(data.user)
      toast.success(`Welcome back, ${data.user.first_name || data.user.email}!`)
      navigate(from, { replace: true })
    },
    onError: () => toast.error('Invalid email or password.')
  })

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">ShopKart</div>
        <h1 className="auth-title">Welcome back</h1>
        <p className="auth-sub">Sign in to your account to continue</p>

        <div className="auth-form">
          <div className="field">
            <label>Email</label>
            <input type="email" placeholder="you@example.com"
              value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
              onKeyDown={e => e.key === 'Enter' && mutate()} />
          </div>
          <div className="field">
            <label>Password</label>
            <input type="password" placeholder="••••••••"
              value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
              onKeyDown={e => e.key === 'Enter' && mutate()} />
          </div>
          <button className="auth-submit" onClick={() => mutate()} disabled={isPending}>
            {isPending ? 'Signing in…' : 'Sign In'}
          </button>
        </div>

        <div className="auth-demo">
          <p>Demo account:</p>
          <button onClick={() => setForm({ email: 'admin@shopkart.com', password: 'Admin@1234' })}>
            Fill demo credentials
          </button>
        </div>

        <p className="auth-switch">
          Don't have an account? <Link to="/register">Create one →</Link>
        </p>
      </div>
    </div>
  )
}
