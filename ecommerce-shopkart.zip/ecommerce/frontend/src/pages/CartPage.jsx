import { Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getCart, updateCartItem, removeCartItem } from '../api'
import { useCartStore } from '../store'
import './CartPage.css'

export default function CartPage() {
  const { setCart } = useCartStore()
  const qc = useQueryClient()

  const { data: cart, isLoading } = useQuery({
    queryKey: ['cart'],
    queryFn: () => getCart().then(r => r.data),
    onSuccess: (d) => setCart(d),
  })

  const updateMutation = useMutation({
    mutationFn: ({ id, qty }) => updateCartItem(id, { quantity: qty }),
    onSuccess: ({ data }) => { setCart(data); qc.invalidateQueries(['cart']) }
  })
  const removeMutation = useMutation({
    mutationFn: (id) => removeCartItem(id),
    onSuccess: ({ data }) => { setCart(data); qc.invalidateQueries(['cart']) }
  })

  const items = cart?.items || []
  const subtotal = Number(cart?.total || 0)
  const shippingCost = subtotal >= 999 ? 0 : 99
  const tax = subtotal * 0.18
  const total = subtotal + shippingCost + tax

  if (isLoading) return <div className="container cart-page"><p>Loading cart…</p></div>

  return (
    <div className="container cart-page">
      <h1 className="cart-title">Your Cart</h1>

      {items.length === 0 ? (
        <div className="cart-empty">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.3">
            <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/>
          </svg>
          <h2>Your cart is empty</h2>
          <p>Browse our products and find something you love.</p>
          <Link to="/products" className="btn-shop">Start Shopping →</Link>
        </div>
      ) : (
        <div className="cart-layout">
          <div className="cart-items">
            <div className="cart-header-row">
              <span>Product</span>
              <span>Price</span>
              <span>Quantity</span>
              <span>Subtotal</span>
            </div>
            {items.map(item => (
              <div key={item.id} className="cart-row fade-up">
                <div className="cr-product">
                  <div className="cr-image">
                    {item.product?.primary_image
                      ? <img src={item.product.primary_image} alt={item.product.name} />
                      : <div className="cr-img-placeholder" />}
                  </div>
                  <div className="cr-info">
                    <Link to={`/products/${item.product?.slug}`} className="cr-name">
                      {item.product?.name}
                    </Link>
                    {item.variant_name && <p className="cr-variant">{item.variant_name}</p>}
                    <button className="cr-remove" onClick={() => removeMutation.mutate(item.id)}>
                      Remove
                    </button>
                  </div>
                </div>
                <div className="cr-price">₹{Number(item.unit_price).toLocaleString('en-IN')}</div>
                <div className="cr-qty">
                  <button onClick={() => updateMutation.mutate({ id: item.id, qty: item.quantity - 1 })} disabled={item.quantity <= 1}>−</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => updateMutation.mutate({ id: item.id, qty: item.quantity + 1 })}>+</button>
                </div>
                <div className="cr-subtotal">₹{Number(item.subtotal).toLocaleString('en-IN')}</div>
              </div>
            ))}
          </div>

          <div className="cart-summary">
            <h2>Order Summary</h2>
            <div className="cs-rows">
              <div className="cs-row"><span>Subtotal ({cart?.item_count} items)</span><span>₹{subtotal.toLocaleString('en-IN')}</span></div>
              <div className="cs-row">
                <span>Shipping</span>
                <span className={shippingCost === 0 ? 'free-ship' : ''}>{shippingCost === 0 ? 'Free' : `₹${shippingCost}`}</span>
              </div>
              <div className="cs-row"><span>GST (18%)</span><span>₹{tax.toFixed(2)}</span></div>
              {shippingCost > 0 && (
                <p className="ship-threshold">
                  Add ₹{(999 - subtotal).toFixed(0)} more for free shipping
                </p>
              )}
              <div className="cs-row cs-total"><span>Total</span><span>₹{total.toLocaleString('en-IN', { maximumFractionDigits: 2 })}</span></div>
            </div>
            <Link to="/checkout" className="btn-checkout">Proceed to Checkout →</Link>
            <Link to="/products" className="btn-continue">← Continue Shopping</Link>
          </div>
        </div>
      )}
    </div>
  )
}
